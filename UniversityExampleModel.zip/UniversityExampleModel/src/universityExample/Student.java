/**
 */
package universityExample;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Student</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link universityExample.Student#getStudentName <em>Student Name</em>}</li>
 *   <li>{@link universityExample.Student#getStudentID <em>Student ID</em>}</li>
 *   <li>{@link universityExample.Student#getCoursesEnrolled <em>Courses Enrolled</em>}</li>
 * </ul>
 *
 * @see universityExample.UniversityExamplePackage#getStudent()
 * @model
 * @generated
 */
public interface Student extends EObject {
	/**
	 * Returns the value of the '<em><b>Student Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Student Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Student Name</em>' attribute.
	 * @see #setStudentName(String)
	 * @see universityExample.UniversityExamplePackage#getStudent_StudentName()
	 * @model
	 * @generated
	 */
	String getStudentName();

	/**
	 * Sets the value of the '{@link universityExample.Student#getStudentName <em>Student Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Student Name</em>' attribute.
	 * @see #getStudentName()
	 * @generated
	 */
	void setStudentName(String value);

	/**
	 * Returns the value of the '<em><b>Student ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Student ID</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Student ID</em>' attribute.
	 * @see #setStudentID(int)
	 * @see universityExample.UniversityExamplePackage#getStudent_StudentID()
	 * @model
	 * @generated
	 */
	int getStudentID();

	/**
	 * Sets the value of the '{@link universityExample.Student#getStudentID <em>Student ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Student ID</em>' attribute.
	 * @see #getStudentID()
	 * @generated
	 */
	void setStudentID(int value);

	/**
	 * Returns the value of the '<em><b>Courses Enrolled</b></em>' containment reference list.
	 * The list contents are of type {@link universityExample.Course}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Courses Enrolled</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Courses Enrolled</em>' containment reference list.
	 * @see universityExample.UniversityExamplePackage#getStudent_CoursesEnrolled()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Course> getCoursesEnrolled();

} // Student
