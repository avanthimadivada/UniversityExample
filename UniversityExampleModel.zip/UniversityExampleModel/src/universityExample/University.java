/**
 */
package universityExample;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>University</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link universityExample.University#getUniName <em>Uni Name</em>}</li>
 *   <li>{@link universityExample.University#getStudents <em>Students</em>}</li>
 * </ul>
 *
 * @see universityExample.UniversityExamplePackage#getUniversity()
 * @model
 * @generated
 */
public interface University extends EObject {
	/**
	 * Returns the value of the '<em><b>Uni Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Uni Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Uni Name</em>' attribute.
	 * @see #setUniName(String)
	 * @see universityExample.UniversityExamplePackage#getUniversity_UniName()
	 * @model
	 * @generated
	 */
	String getUniName();

	/**
	 * Sets the value of the '{@link universityExample.University#getUniName <em>Uni Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Uni Name</em>' attribute.
	 * @see #getUniName()
	 * @generated
	 */
	void setUniName(String value);

	/**
	 * Returns the value of the '<em><b>Students</b></em>' containment reference list.
	 * The list contents are of type {@link universityExample.Student}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Students</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Students</em>' containment reference list.
	 * @see universityExample.UniversityExamplePackage#getUniversity_Students()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Student> getStudents();

} // University
