package universityexampleplugin.views;


import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.part.*;
import org.eclipse.jface.viewers.*;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.jface.action.*;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.ui.*;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.SWT;

import universityExample.*;
import universityExample.impl.*;

import org.eclipse.jface.viewers.CheckboxTreeViewer;


/**
 * This sample class demonstrates how to plug-in a new
 * workbench view. The view shows data obtained from the
 * model. The sample creates a dummy model on the fly,
 * but a real implementation would connect to the model
 * available either in this or another plug-in (e.g. the workspace).
 * The view is connected to the model using a content provider.
 * <p>
 * The view uses a label provider to define how model
 * objects should be presented in the view. Each
 * view can present the same model objects using
 * different labels and icons, if needed. Alternatively,
 * a single label provider can be shared between views
 * in order to ensure that objects of the same type are
 * presented in the same way everywhere.
 * <p>
 */

public class ViewCoursesEnrolled extends ViewPart {

	/**
	 * The ID of the view as specified by the extension.
	 */
	public static final String ID = "universityexampleplugin.views.ViewCoursesEnrolled";

	private CheckboxTreeViewer viewer;
	private Action action1;
	private Action action2;
	private Action doubleClickAction;
	
	private Course c1,c2,c3,c4,c5;
	private Student s1,s2,s3,s4;
	private University uni;

	/*
	 * The content provider class is responsible for
	 * providing objects to the view. It can wrap
	 * existing objects in adapters or simply return
	 * objects as-is. These objects may be sensitive
	 * to the current input of the view, or ignore
	 * it and always show the same content 
	 * (like Task List, for example).
	 */
	 
	/*
	 * Just creating instances here to simplify things.
	 * There are other ways to do that, please refer the tutorial links 
	 * provided in the reference section
	 * 
	 */
	void createInstances(){
		UniversityExampleFactory uf=new UniversityExampleFactoryImpl();
		
		c1=uf.createCourse();
		c1.setCourseName("CourseA");
		c1.setDuration(6);
		c2=uf.createCourse();
		c2.setCourseName("CourseB");
		c2.setDuration(6);
		c3=uf.createCourse();
		c3.setCourseName("CourseC");
		c3.setDuration(6);
		c4=uf.createCourse();
		c4.setCourseName("CourseD");
		c4.setDuration(2);
		c5=uf.createCourse();
		c5.setCourseName("CourseE");
		c5.setDuration(1);
		
		s1=uf.createStudent();
		s1.setStudentID(1);
		s1.setStudentName("Student1");
				
		s2=uf.createStudent();
		s2.setStudentID(2);
		s2.setStudentName("Student2");
		s2.getCoursesEnrolled().add(c1);
				
		s3=uf.createStudent();
		s3.setStudentID(3);
		s3.setStudentName("Student3");
		s3.getCoursesEnrolled().add(c4);
		s3.getCoursesEnrolled().add(c5);
		
		s4=uf.createStudent();
		s4.setStudentID(4);
		s4.setStudentName("Student4");
		s4.getCoursesEnrolled().add(c2);
		s4.getCoursesEnrolled().add(c3);
		
		uni=uf.createUniversity();
		uni.setUniName("UniExample");
		uni.getStudents().add(s1);
		uni.getStudents().add(s2);
		uni.getStudents().add(s3);
		uni.getStudents().add(s4);
		
	}
	
	
	class ViewContentProvider implements ITreeContentProvider {

		@Override
		public void dispose() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public Object[] getElements(Object inputElement) {
			
			/*
			 * Assigning and changing the root and children based on the selection
			 */
			if(inputElement.getClass()==UniversityImpl.class){
				University root=(UniversityImpl)inputElement;
				if(root.getStudents().size()>0){
					return root.getStudents().toArray();
				}
				else{
			    	return null;
			    }
			}
			else if(inputElement.getClass()==StudentImpl.class){
				Student root=(StudentImpl)inputElement;
				if(root.getCoursesEnrolled().size()>0){
					return root.getCoursesEnrolled().toArray();
				}
				else{
			    	return null;
			    }
			}
			else
				return null;
		}

		@Override
		public Object[] getChildren(Object parentElement) {
			/*
			 * Assigning and changing the root and children based on the selection
			 */
			if(parentElement.getClass()==UniversityImpl.class){
				University pa=(UniversityImpl)parentElement;
				if(pa.getStudents().size()>0){
					return pa.getStudents().toArray();
				}
				else
					return null;
			}
			else if(parentElement.getClass()==StudentImpl.class){
				Student pa=(StudentImpl)parentElement;
				if(pa.getCoursesEnrolled().size()>0){
					return pa.getCoursesEnrolled().toArray();
				}
				else{
			    	return null;
			    }
			}
			else
				return null;
		}

		@Override
		public Object getParent(Object element) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public boolean hasChildren(Object element) {
			if(element.getClass()==UniversityImpl.class){
				University pa=(UniversityImpl)element;
				if(pa.getStudents().size()>0){
					return true;
				}
				else
					return false;
			}
			else if(element.getClass()==StudentImpl.class){
				Student pa=(StudentImpl)element;
				if(pa.getCoursesEnrolled().size()>0){
					return true;
				}
				else{
			    	return false;
			    }
			}
			else
				return false;
		}
		
	}
	class ViewLabelProvider extends ColumnLabelProvider implements ILabelProvider {
		@Override
		public void addListener(ILabelProviderListener listener) {
		}

		@Override
		public void dispose() {
		}

		@Override
		public boolean isLabelProperty(Object element, String property) {
			return false;
		}

		@Override
		public void removeListener(ILabelProviderListener listener) {
		}

		@Override
		public Image getImage(Object element) {
			return null;
		}

		@Override
		public String getText(Object element) {
			if(element.getClass()==UniversityImpl.class){
				University pa=(UniversityImpl)element;
				return pa.getUniName();
			}
			else if(element.getClass()==StudentImpl.class){
				Student pa=(StudentImpl)element;
				return pa.getStudentName();
			}
			else{
				Course pa=(CourseImpl)element;
				return pa.getCourseName();
			}
		}
		
		@Override
		public String getToolTipText(Object element) {
			return null;
		}		

		@Override
		public int getToolTipDisplayDelayTime(Object object) {
		   return 0;
		}
	}
	class NameSorter extends ViewerSorter {
	}

	/**
	 * The constructor.
	 */
	public ViewCoursesEnrolled() {
	}

	/**
	 * This is a callback that will allow us
	 * to create the viewer and initialize it.
	 */
	public void createPartControl(Composite parent) {
		
		createInstances();
		Label la=new Label(parent,SWT.NONE);
		la.setText(uni.getUniName());
		
		viewer = new CheckboxTreeViewer(parent,SWT.MULTI | SWT.H_SCROLL | SWT.V_SCROLL);
		viewer.getTree().setLayoutData(new GridData(GridData.FILL_BOTH));;
		viewer.setContentProvider(new ViewContentProvider());
		viewer.setLabelProvider(new ViewLabelProvider());
		viewer.setInput(uni);
		
		viewer.addSelectionChangedListener(new ISelectionChangedListener() {
			
			@Override
			public void selectionChanged(SelectionChangedEvent event) {
				// TODO Auto-generated method stub
				
			}
		});

		// Create the help context id for the viewer's control
		PlatformUI.getWorkbench().getHelpSystem().setHelp(viewer.getControl(), "UniversityExamplePlugin.viewer");
		makeActions();
		hookContextMenu();
		hookDoubleClickAction();
		contributeToActionBars();
	}

	private void hookContextMenu() {
		MenuManager menuMgr = new MenuManager("#PopupMenu");
		menuMgr.setRemoveAllWhenShown(true);
		menuMgr.addMenuListener(new IMenuListener() {
			public void menuAboutToShow(IMenuManager manager) {
				ViewCoursesEnrolled.this.fillContextMenu(manager);
			}
		});
		Menu menu = menuMgr.createContextMenu(viewer.getControl());
		viewer.getControl().setMenu(menu);
		getSite().registerContextMenu(menuMgr, viewer);
	}

	private void contributeToActionBars() {
		IActionBars bars = getViewSite().getActionBars();
		fillLocalPullDown(bars.getMenuManager());
		fillLocalToolBar(bars.getToolBarManager());
	}

	private void fillLocalPullDown(IMenuManager manager) {
		manager.add(action1);
		manager.add(new Separator());
		manager.add(action2);
	}

	private void fillContextMenu(IMenuManager manager) {
		manager.add(action1);
		manager.add(action2);
		// Other plug-ins can contribute there actions here
		manager.add(new Separator(IWorkbenchActionConstants.MB_ADDITIONS));
	}
	
	private void fillLocalToolBar(IToolBarManager manager) {
		manager.add(action1);
		manager.add(action2);
	}

	private void makeActions() {
		action1 = new Action() {
			public void run() {
				showMessage("Action 1 executed");
			}
		};
		action1.setText("Action 1");
		action1.setToolTipText("Action 1 tooltip");
		action1.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
			getImageDescriptor(ISharedImages.IMG_OBJS_INFO_TSK));
		
		action2 = new Action() {
			public void run() {
				showMessage("Action 2 executed");
			}
		};
		action2.setText("Action 2");
		action2.setToolTipText("Action 2 tooltip");
		action2.setImageDescriptor(PlatformUI.getWorkbench().getSharedImages().
				getImageDescriptor(ISharedImages.IMG_OBJS_INFO_TSK));
		doubleClickAction = new Action() {
			public void run() {
				ISelection selection = viewer.getSelection();
				Object obj = ((IStructuredSelection)selection).getFirstElement();
				showMessage("Double-click detected on "+obj.toString());
			}
		};
	}

	private void hookDoubleClickAction() {
		viewer.addDoubleClickListener(new IDoubleClickListener() {
			public void doubleClick(DoubleClickEvent event) {
				doubleClickAction.run();
			}
		});
	}
	private void showMessage(String message) {
		MessageDialog.openInformation(
			viewer.getControl().getShell(),
			"ViewCoursesEnrolled",
			message);
	}

	/**
	 * Passing the focus request to the viewer's control.
	 */
	public void setFocus() {
		viewer.getControl().setFocus();
	}
}